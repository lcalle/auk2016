#============================================
#     A b u n d a n c e   M o d e l s        
#============================================
#-------------------
# data description
#-------------------
#     species: LBHE,GWHE
#       abund: abundance for survey day
#          ID: unique survey id
#        date: month/day/year of survey
#      SurvST: survey start time (minute-time: 0=00:00, 1440=24:00)
#    SurvElap: elapsed survey time (duration in minutes)
#   SurvST2LT: survey start time relative to low tide (minutes)
# SurvST2sunR: survey start time relative to sunrise (minutes)
#    startloc: survey start location
#      season: season of survey
#    wind_avg: average wind speed m/s
#    wind_dir: average wind direction
#      LTtime: time of low tide (minute-time: 0=00:00, 1440=24:00)
#        sunR: time of sunrise (minute-time: 0=00:00, 1440=24:00)
# LTtime2sunR: time of low tide relative to sunrise
#       LThgt: low tide height (m)
#       MPraw: moon illumination as fraction of full moon
#        MP50: moon phase (MPraw) standardized via (|MPraw|-0.50)/0.50 (0=quartermoon; 1=full or new moon) 
#     HectHrs: total shallow-water availability in survey area (hectare-hrs)
#  countAvail: count of grid-cells with any shallow-water availability in survey area
#------------------- ..end of data description

#get data
abunddat <- read.table("distribution_surveys_lbhe_gwhe_AbundModel.csv",header=TRUE, sep=",", na.strings="NA", dec=".", strip.white=TRUE)

table(abunddat$species)
names(abunddat)

#---------------------------------------------
#  L B H E :   M o d e l  S e l e c t i o n  
#---------------------------------------------
#subset for LBHE data
aLBHE <- abunddat[which(abunddat$species=="LBHE"),]

#................
#  m o d e l s
#................
	#set models in list
  abundmodels <- list()

	#global models and null (season only)
	abundmodels[[1]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + HectHrs + season,data=aLBHE,family="poisson")
	abundmodels[[2]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + HectHrs + season + MP50:season,data=aLBHE,family="poisson")
	abundmodels[[3]] <- glm(abund ~ season,data=aLBHE,family="poisson")
	
	#survey effects
	abundmodels[[4]] <- glm(abund ~ SurvST2sunR + SurvST2LT + season,data=aLBHE,family="poisson")
	abundmodels[[5]] <- glm(abund ~ SurvST2sunR + season,data=aLBHE,family="poisson")
	abundmodels[[6]] <- glm(abund ~ SurvST2LT + season,data=aLBHE,family="poisson")
	
	#habitat: moon phase
	abundmodels[[7]] <- glm(abund ~ MP50 + season,data=aLBHE,family="poisson")
	abundmodels[[8]] <- glm(abund ~ MP50 + season + MP50:season,data=aLBHE,family="poisson")
	
	#habitat: availability
	abundmodels[[9]] <- glm(abund ~ HectHrs + season,data=aLBHE,family="poisson")
	
	#survey effects & habitat:moonphase
	abundmodels[[10]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + season,data=aLBHE,family="poisson")
	abundmodels[[11]] <- glm(abund ~ SurvST2sunR + MP50 + season,data=aLBHE,family="poisson")
	abundmodels[[12]] <- glm(abund ~ SurvST2LT + MP50 + season,data=aLBHE,family="poisson")
	#..w/ interaction terms for moonphase:season
	abundmodels[[13]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + season + MP50:season,data=aLBHE,family="poisson")
	abundmodels[[14]] <- glm(abund ~ SurvST2sunR + MP50 + season + MP50:season,data=aLBHE,family="poisson")
	abundmodels[[15]] <- glm(abund ~ SurvST2LT + MP50 + season + MP50:season,data=aLBHE,family="poisson")
	
	#survey effects & habitat:availability
	abundmodels[[16]] <- glm(abund ~ SurvST2sunR + SurvST2LT + HectHrs + season,data=aLBHE,family="poisson")
	abundmodels[[17]] <- glm(abund ~ SurvST2sunR + HectHrs + season,data=aLBHE,family="poisson")
	abundmodels[[18]] <- glm(abund ~ SurvST2LT + HectHrs + season,data=aLBHE,family="poisson")
	
	#habitat:moonphase & habitat:availability
	abundmodels[[19]] <- glm(abund ~ MP50 + HectHrs + season,data=aLBHE,family="poisson")
	abundmodels[[20]] <- glm(abund ~ SurvST2sunR + MP50 + HectHrs + season,data=aLBHE,family="poisson")
	abundmodels[[21]] <- glm(abund ~ SurvST2LT + MP50 + HectHrs + season,data=aLBHE,family="poisson")
	#..w/ interaction terms for moonphase:season
	abundmodels[[22]] <- glm(abund ~ MP50 + HectHrs + season + MP50:season,data=aLBHE,family="poisson")
	abundmodels[[23]] <- glm(abund ~ SurvST2sunR + MP50 + HectHrs + season + MP50:season,data=aLBHE,family="poisson")
	abundmodels[[24]] <- glm(abund ~ SurvST2LT + MP50 + HectHrs + season + MP50:season,data=aLBHE,family="poisson")

#...................................
#  check summaries and extract AICc
#...................................
#check summaries of model outputs
summary(abundmodels[[1]])

library(AICcmodavg) #use AICc
#get stats: parameters (edf), AICc
tmp_edf <- tmp_aic <- tmp_aicc <- list(); 
for(i in 1:24){
	tmp_edf[[i]]  <- extractAIC(abundmodels[[i]])[1]
  tmp_aic[[i]]  <- AICcmodavg::AICc(abundmodels[[i]])
  tmp_aicc[[i]] <- extractAIC(abundmodels[[i]])[2]
}
#table stats
abund_model_AICdf <- data.frame(Modelref = 1:24,
	                                   AIC = unlist(tmp_aic),
																    AICc = unlist(tmp_aicc),
	                                   edf = unlist(tmp_edf))
#sort based on lowest AICc
abund_model_AICdf <- abund_model_AICdf[order(abund_model_AICdf$AICc),]
#compute delta AICc
abund_model_AICdf$deltaAICc <- abund_model_AICdf$AICc - abund_model_AICdf$AICc[1]

#inspect top models and check for redundant models (pretending variables)
top_models <- abund_model_AICdf[which(abund_model_AICdf$deltaAICc <= 10),]
  #manual: print summary for each Modelref
  summary(abundmodels[[1]]) #modelrefs: 1,20,2,23

#---------------------------------------------
#  G W H E :   M o d e l  S e l e c t i o n  
#---------------------------------------------
#subset for GWHE data
aGWHE <- abunddat[which(abunddat$species=="GWHE"),]

#................
#  m o d e l s
#................
	#set models in list
  abundmodels <- list()

	#global models and null (season only)
	abundmodels[[1]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + HectHrs + season,data=aGWHE,family="poisson")
	abundmodels[[2]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + HectHrs + season + MP50:season,data=aGWHE,family="poisson")
	abundmodels[[3]] <- glm(abund ~ season,data=aGWHE,family="poisson")
	
	#survey effects
	abundmodels[[4]] <- glm(abund ~ SurvST2sunR + SurvST2LT + season,data=aGWHE,family="poisson")
	abundmodels[[5]] <- glm(abund ~ SurvST2sunR + season,data=aGWHE,family="poisson")
	abundmodels[[6]] <- glm(abund ~ SurvST2LT + season,data=aGWHE,family="poisson")
	
	#habitat: moon phase
	abundmodels[[7]] <- glm(abund ~ MP50 + season,data=aGWHE,family="poisson")
	abundmodels[[8]] <- glm(abund ~ MP50 + season + MP50:season,data=aGWHE,family="poisson")
	
	#habitat: availability
	abundmodels[[9]] <- glm(abund ~ HectHrs + season,data=aGWHE,family="poisson")
	
	#survey effects & habitat:moonphase
	abundmodels[[10]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + season,data=aGWHE,family="poisson")
	abundmodels[[11]] <- glm(abund ~ SurvST2sunR + MP50 + season,data=aGWHE,family="poisson")
	abundmodels[[12]] <- glm(abund ~ SurvST2LT + MP50 + season,data=aGWHE,family="poisson")
	#..w/ interaction terms for moonphase:season
	abundmodels[[13]] <- glm(abund ~ SurvST2sunR + SurvST2LT + MP50 + season + MP50:season,data=aGWHE,family="poisson")
	abundmodels[[14]] <- glm(abund ~ SurvST2sunR + MP50 + season + MP50:season,data=aGWHE,family="poisson")
	abundmodels[[15]] <- glm(abund ~ SurvST2LT + MP50 + season + MP50:season,data=aGWHE,family="poisson")
	
	#survey effects & habitat:availability
	abundmodels[[16]] <- glm(abund ~ SurvST2sunR + SurvST2LT + HectHrs + season,data=aGWHE,family="poisson")
	abundmodels[[17]] <- glm(abund ~ SurvST2sunR + HectHrs + season,data=aGWHE,family="poisson")
	abundmodels[[18]] <- glm(abund ~ SurvST2LT + HectHrs + season,data=aGWHE,family="poisson")
	
	#habitat:moonphase & habitat:availability
	abundmodels[[19]] <- glm(abund ~ MP50 + HectHrs + season,data=aGWHE,family="poisson")
	abundmodels[[20]] <- glm(abund ~ SurvST2sunR + MP50 + HectHrs + season,data=aGWHE,family="poisson")
	abundmodels[[21]] <- glm(abund ~ SurvST2LT + MP50 + HectHrs + season,data=aGWHE,family="poisson")
	#..w/ interaction terms for moonphase:season
	abundmodels[[22]] <- glm(abund ~ MP50 + HectHrs + season + MP50:season,data=aGWHE,family="poisson")
	abundmodels[[23]] <- glm(abund ~ SurvST2sunR + MP50 + HectHrs + season + MP50:season,data=aGWHE,family="poisson")
	abundmodels[[24]] <- glm(abund ~ SurvST2LT + MP50 + HectHrs + season + MP50:season,data=aGWHE,family="poisson")

#...................................
#  check summaries and extract AICc
#...................................
#check summaries of model outputs
summary(abundmodels[[1]])

library(AICcmodavg) #use AICc
#get stats: parameters (edf), AICc
tmp_edf <- tmp_aic <- tmp_aicc <- list(); 
for(i in 1:24){
	tmp_edf[[i]]  <- extractAIC(abundmodels[[i]])[1]
	tmp_aic[[i]]  <- extractAIC(abundmodels[[i]])[2]
  tmp_aicc[[i]] <- AICcmodavg::AICc(abundmodels[[i]])
}
#table stats
abund_model_AICdf <- data.frame(Modelref = 1:24,
	                                   AIC = unlist(tmp_aic),
																    AICc = unlist(tmp_aicc),
	                                   edf = unlist(tmp_edf))
#sort based on lowest AICc
abund_model_AICdf <- abund_model_AICdf[order(abund_model_AICdf$AICc),]
#compute delta AICc
abund_model_AICdf$deltaAICc <- abund_model_AICdf$AICc - abund_model_AICdf$AICc[1]

#inspect top models and check for redundant models (pretending variables)
top_models <- abund_model_AICdf[which(abund_model_AICdf$deltaAICc <= 10),]
  #manual: print summary for each Modelref
  summary(abundmodels[[1]]) #modelrefs: 23,2,20,24

  #NOTE: modelref 2 is a duplicate of 23, can throw out